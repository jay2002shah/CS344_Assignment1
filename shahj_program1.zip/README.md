# CS344_Assignment1

// In this assignment I made a program that reads a csv file.

- first compile the code with gcc--std=gnu99
- run the code
- will ask the user to enter a number to do the certian operation
- then the operation will run and show the information

- press 4 to exit the code
